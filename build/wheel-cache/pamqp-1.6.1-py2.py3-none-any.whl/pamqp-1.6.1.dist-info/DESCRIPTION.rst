All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of the paqmp nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Description: pamqp
        =====
        
        pamqp is a pure-python AMQP 0-9-1 frame encoder and decoder. The aim is to create a
        client agnostic python encoder and decoder for general purpose use.
        
        |PyPI version| |Downloads| |Build Status| |Coverage| |License|
        
        Documentation
        -------------
        http://pamqp.readthedocs.org
        
        License
        -------
        BSD
        
        Python Versions Supported
        -------------------------
        2.6+, 3.2+
        
        Requirements
        ------------
        codegen (not required for use) requires lxml.
        
        .. |PyPI version| image:: https://badge.fury.io/py/pamqp.svg?
           :target: http://badge.fury.io/py/pamqp
           
        .. |Downloads| image:: https://pypip.in/d/pamqp/badge.svg?
           :target: https://pypi.python.org/pypi/pamqp
        
        .. |Build Status| image:: https://travis-ci.org/gmr/pamqp.png?branch=master
           :target: https://travis-ci.org/gmr/pamqp
           
        .. |Coverage| image:: https://coveralls.io/repos/gmr/pamqp/badge.png
           :target: https://coveralls.io/r/gmr/pamqp
        
        .. |License| image:: https://pypip.in/license/pamqp/badge.svg?
           :target: https://pypi.python.org/pypi/pamqp
        
Platform: UNKNOWN
Classifier: Development Status :: 5 - Production/Stable
Classifier: Intended Audience :: Developers
Classifier: Programming Language :: Python
Classifier: Programming Language :: Python :: 2
Classifier: Programming Language :: Python :: 2.6
Classifier: Programming Language :: Python :: 2.7
Classifier: Programming Language :: Python :: 3
Classifier: Programming Language :: Python :: 3.2
Classifier: Programming Language :: Python :: 3.3
Classifier: Programming Language :: Python :: 3.4
Classifier: License :: OSI Approved :: BSD License
Classifier: Operating System :: OS Independent
Classifier: Topic :: Communications
Classifier: Topic :: Internet
Classifier: Topic :: Software Development :: Libraries
