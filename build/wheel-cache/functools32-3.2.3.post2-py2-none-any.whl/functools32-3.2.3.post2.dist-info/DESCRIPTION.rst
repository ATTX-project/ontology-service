This is a backport of the functools standard library module from
Python 3.2.3 for use on Python 2.7 and PyPy. It includes
new features `lru_cache` (Least-recently-used cache decorator).

